import java.sql.*;

public class TransactionService {
    public void recordTransaction(int accountId, String type, double amount) throws SQLException {
        Connection conn = DBConnection.getConnection();
        String sql = "INSERT INTO transactions(accountId, type, amount) VALUES (?, ?, ?)";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, accountId);
        ps.setString(2, type);
        ps.setDouble(3, amount);
        ps.executeUpdate();
    }

    public void showTransactions(int accountId) throws SQLException {
        Connection conn = DBConnection.getConnection();
        String sql = "SELECT * FROM transactions WHERE accountId = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, accountId);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            System.out.println(rs.getString("type") + " ₹" + rs.getDouble("amount") + " on " + rs.getTimestamp("timestamp"));
        }
    }
}