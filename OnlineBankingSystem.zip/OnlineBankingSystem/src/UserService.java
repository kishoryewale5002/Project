import java.sql.*;

public class UserService {
    public boolean register(String username, String password) throws SQLException {
        Connection conn = DBConnection.getConnection();
        String sql = "INSERT INTO users(username, password) VALUES (?, ?)";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, username);
        ps.setString(2, password);
        return ps.executeUpdate() > 0;
    }

    public int login(String username, String password) throws SQLException {
        Connection conn = DBConnection.getConnection();
        String sql = "SELECT id FROM users WHERE username=? AND password=?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, username);
        ps.setString(2, password);
        ResultSet rs = ps.executeQuery();
        return rs.next() ? rs.getInt("id") : -1;
    }
}