import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
        UserService userService = new UserService();
        AccountService accountService = new AccountService();
        TransactionService transactionService = new TransactionService();

        System.out.println("Welcome to Online Banking System");
        System.out.println("1. Register\n2. Login");
        int choice = sc.nextInt();
        sc.nextLine();

        if (choice == 1) {
            System.out.print("Username: ");
            String username = sc.nextLine();
            System.out.print("Password: ");
            String password = sc.nextLine();
            if (userService.register(username, password)) {
                System.out.println("Registration successful!");
            }
        }

        System.out.print("Login Username: ");
        String username = sc.nextLine();
        System.out.print("Password: ");
        String password = sc.nextLine();
        int userId = userService.login(username, password);

        if (userId != -1) {
            System.out.println("Login successful!");
            accountService.createAccount(userId);
            System.out.println("Account created.");

            System.out.println("Choose: 1.Deposit 2.Withdraw 3.Balance 4.Transactions");
            int action = sc.nextInt();
            int accountId = userId;
            if (action == 1) {
                System.out.print("Amount: ");
                double amt = sc.nextDouble();
                accountService.deposit(accountId, amt);
                transactionService.recordTransaction(accountId, "Deposit", amt);
            } else if (action == 2) {
                System.out.print("Amount: ");
                double amt = sc.nextDouble();
                accountService.withdraw(accountId, amt);
                transactionService.recordTransaction(accountId, "Withdraw", amt);
            } else if (action == 3) {
                System.out.println("Balance: ₹" + accountService.getBalance(accountId));
            } else if (action == 4) {
                transactionService.showTransactions(accountId);
            }
        } else {
            System.out.println("Login failed.");
        }
    }
}