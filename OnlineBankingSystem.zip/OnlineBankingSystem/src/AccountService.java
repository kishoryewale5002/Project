import java.sql.*;

public class AccountService {
    public void createAccount(int userId) throws SQLException {
        Connection conn = DBConnection.getConnection();
        String sql = "INSERT INTO accounts(userId, balance) VALUES (?, 0)";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, userId);
        ps.executeUpdate();
    }

    public void deposit(int accountId, double amount) throws SQLException {
        Connection conn = DBConnection.getConnection();
        String sql = "UPDATE accounts SET balance = balance + ? WHERE accountId = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setDouble(1, amount);
        ps.setInt(2, accountId);
        ps.executeUpdate();
    }

    public void withdraw(int accountId, double amount) throws SQLException {
        Connection conn = DBConnection.getConnection();
        String sql = "UPDATE accounts SET balance = balance - ? WHERE accountId = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setDouble(1, amount);
        ps.setInt(2, accountId);
        ps.executeUpdate();
    }

    public double getBalance(int accountId) throws SQLException {
        Connection conn = DBConnection.getConnection();
        String sql = "SELECT balance FROM accounts WHERE accountId = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, accountId);
        ResultSet rs = ps.executeQuery();
        return rs.next() ? rs.getDouble("balance") : 0;
    }
}