CREATE DATABASE bankSystem;
USE bankSystem;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE,
    password VARCHAR(50)
);

CREATE TABLE accounts (
    accountId INT AUTO_INCREMENT PRIMARY KEY,
    userId INT,
    balance DOUBLE DEFAULT 0,
    FOREIGN KEY (userId) REFERENCES users(id)
);

CREATE TABLE transactions (
    transactionId INT AUTO_INCREMENT PRIMARY KEY,
    accountId INT,
    type VARCHAR(10),
    amount DOUBLE,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (accountId) REFERENCES accounts(accountId)
);